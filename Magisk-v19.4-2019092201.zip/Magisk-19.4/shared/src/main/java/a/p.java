package a;

import com.topjohnwu.magisk.utils.FileProvider;

public class p extends FileProvider {
    /* Stub */
}
