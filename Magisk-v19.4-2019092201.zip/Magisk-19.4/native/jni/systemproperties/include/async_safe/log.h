#pragma once

#define async_safe_format_buffer snprintf
#define async_safe_format_log(...)  /* NOP */
