package com.topjohnwu.magisk.model.entity

data class Version(val version: String, val versionCode: Int)