package a;

import com.topjohnwu.magisk.ui.flash.FlashActivity;

public class f extends FlashActivity {
    /* stub */
}
