package a;

import com.topjohnwu.magisk.ui.SplashActivity;

public class c extends SplashActivity {
    /* stub */
}
