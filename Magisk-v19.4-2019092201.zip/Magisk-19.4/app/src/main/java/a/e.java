package a;

import com.topjohnwu.magisk.App;

public class e extends App {
    /* stub */
}
