package a;

import com.topjohnwu.magisk.ui.surequest.SuRequestActivity;

public class m extends SuRequestActivity {
    /* stub */
}
