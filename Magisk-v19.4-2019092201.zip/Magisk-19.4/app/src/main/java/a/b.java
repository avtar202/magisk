package a;

import com.topjohnwu.magisk.ui.MainActivity;

public class b extends MainActivity {
    /* stub */
}
