# v7.3.2
- Fix potential crash in superuser fragment
- Preserve searched state in repo fragment
